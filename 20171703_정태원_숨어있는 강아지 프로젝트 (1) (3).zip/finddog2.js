// 1.게임 시작 버튼을 클릭히면
// 랜덤으로 사진의 위치를 배열에 담고
// 5초동안 사진을 보여주고 다시 뒤집고 30초를 주고 5초가 남게 되면 화면이 빨간색으로 바뀐다.
var failnum = 0; // 전역 변수
var deck = [];

function play(id) { // 작동하던 음악을 멈추기도하고 정지해있는 음악을 재생한다.
    var audio = document.getElementById(id);
    if (audio.paused) {
        audio.play();
    }else{
        audio.pause();
        audio.currentTime = 0
    }
}

  function checkcard(e){
    const idx2 = deck.indexOf(parseInt(e.id)); // 다른 카드를 골랐을 경우
    if(idx2==-1)
    {
      var backimage = backimages.item(parseInt(e.id));
      setTransform(backimage.parentNode.parentNode, 180);//
      console.log(deck);
      failnum++;
      document.getElementById("remainnum").innerHTML = "남은수 : "+ deck.length;
      document.getElementById("failnum").innerHTML = "실패수 : "+ failnum;
      if(failnum == 5)//최대 5번의 기회를 줍니다.
      {
      var canvas = document.getElementById("canvas");
      var context = canvas.getContext("2d");
      context.font = "italic 100px forte";

      context.strokeStyle = "blue";
      context.lineWidth = 3;
      context.fillStyle = "blue";
      context.fillText("GAME OVER",650, 100)
      play("bgm");
      document.getElementById("remainnum").innerHTML = "";
      document.getElementById("failnum").innerHTML = "";
      document.getElementById("lefthour").innerHTML = "";
      document.getElementById("findanswer").innerHTML = "게임이 종료되었습니다.";
      clearTimeout(y);
      clearInterval(x);
      for (var j = 0; j < 24; j++)// 마지막으로 모든 코드를 보여준다.
      {
        var backimage = backimages.item(j);
        setTransform(backimage.parentNode.parentNode, 180);// 함수 뒤집기 실현
      }
    }
    else//맞는 카드를 골랐을 경우
    {
      var backimage = backimages.item(parseInt(e.id));
      setTransform(backimage.parentNode.parentNode, 180);//
      deck.splice(idx2,1);
      (parseInt(e.id));
      console.log(deck);
      document.getElementById("remainnum").innerHTML = "남은수 : "+ deck.length;
      document.getElementById("failnum").innerHTML = "실패수 : "+ failnum;
      if(deck.length == 0){
        for (var j = 0; j < 24; j++)// 마지막으로 모든 코드를 보여준다.
        {
          var backimage = backimages.item(j);
          setTransform(backimage.parentNode.parentNode, 180);// 함수 뒤집기 실현
        }
        var audio = document.getElementById("bgm"); // 게임이 끝나면 노래 종료
        audio.pause();
        audio.currentTime = 0
        document.getElementById("remainnum").innerHTML = "";
        document.getElementById("failnum").innerHTML = "";
        document.getElementById("lefthour").innerHTML = "";
        document.getElementById("findanswer").innerHTML = "성공하셨습니다!!";
        clearTimeout(y);
        clearInterval(x);
        var canvas = document.getElementById("canvas");
        var context = canvas.getContext("2d");
        context.clearRect(0,0, canvas.width, canvas.height);

        context.font = "italic 100px forte";
        context.strokeStyle = "blue";
        context.lineWidth = 3;
        context.fillStyle = "blue";
        context.fillText("GAME COMPLETE",650, 100)


        }

      }

    }

  }


function setcards(cards){
  // cards = [];
  do{
    cardnum  =  Math.floor(Math.random()*23); //카드의 갯;
  }while(cardnum>14 || cardnum<10) //두번째 난이도 10개에서  14개 사이의 수를 카드 갯수로 가져옵니다.

var i = cardnum;
console.log(i);
while(i > 0)
  {

    var card = Math.floor(Math.random()*23);
    if (cards.indexOf(card)==-1)
    {cards.push(card);
      i--;
    }

  }
  console.log(cards);
}
function setTransform (element, rotationArg) {
    var transfromString = ("rotateY(" + rotationArg + "deg )");
    element.style.transform = transfromString;
}




function gamestart(){
  var canvas = document.getElementById("canvas");
  var context = canvas.getContext("2d");
  context.clearRect(0,0, canvas.width, canvas.height);//canvas 내용물을 지웁니다.
  deck = []; // 덱 초기
  failnum = 0; // 실패 횟수를 초기화
  document.getElementById("findanswer").innerHTML = "정답을 찾으세요."; // 초기화
  var audio = document.getElementById("bgm");
  audio.play(); //노래를 재생
  setcards(deck);
  var starttime = Date.now();
  backimages = document.getElementsByClassName("back");
  let a = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23];
  const idx = a.indexOf(3)



  console.log(deck); //deck 생성완료
  for (var j = 0; j < deck.length; j++)
  {
    var backimage = backimages.item(deck[j]);
    var srcimage = "img/"+j + ".jpeg";
    backimage.src = srcimage;
    const idx = a.indexOf(deck[j]);
    if (idx > -1) a.splice(idx, 1)
  }
  for( var j = 0; j < a.length; j++)
  {
    var backimage = backimages.item(a[j]);
    var srcimage = "img/prodo.jpeg";
    backimage.src = srcimage;
  }


  for (var j = 0; j < 24; j++)
  {
    var backimage = backimages.item(j);
    setTransform(backimage.parentNode.parentNode, 180);
  } //deck을 출현시킨대로 화면 출력
//   for (let count = 0; count < 1000000; count++) {
//
//   console.log(backimages);
//   console.log(checktime-starttime);
//   // if(Date.now()-starttime ==5000)//5초가 되면 카드 뒤집//
//   // {
//   //
//   //   break;
//   //
//   // }
// }

 y = setTimeout(function() { // 4초를  지연시켜서 실행 - 강아지 위치를 확인할 기회를 줌
  for (var j = 0; j < 24; j++)
  {
    var backimage = backimages.item(j);
    setTransform(backimage.parentNode.parentNode, 0);// 함수 뒤집기 실현
    // backimage.parentNode.parentNode.onclick = checkcard(this);
  }
  // for( var i = 0; i < backimages.length; i++ )
  // { var backimage = backimages.item(i);
  //   backimage.style.visibility = "hidden"; }
}, 4000);


var time = 40;
var min = "";
var sec = "";
x = setInterval(function(){
  min =parseInt(time/60);
  sec = time%60;

  if(time >0)
  {
    document.getElementById("lefthour").innerHTML = "남은 시간 : "+min + "분" + sec + "초";
  }
  time--;
  if(time< 20)
    { //시간이 얼마 남지 않았을 경우 시간을 알려주는 창이 깜박 거린다.
      if(time%2 == 1){
        document.getElementById("lefthour").style.backgroundColor = "violet";
      }
      else{
        document.getElementById("lefthour").style.backgroundColor = "#96B1D0";
      }
    }
  if(time<0){
    for (var j = 0; j < 24; j++)// 마지막으로 모든 코드를 보여준다.
    {
      var backimage = backimages.item(j);
      setTransform(backimage.parentNode.parentNode, 180);// 함수 뒤집기 실현
    }
    document.getElementById("lefthour").innerHTML = "시간초과";
    document.getElementById("findanswer").innerHTML = "게임이 종료되었습니다.";
    clearInterval(x);
    var canvas = document.getElementById("canvas");
    var context = canvas.getContext("2d");
    context.font = "italic 100px forte";

    context.strokeStyle = "blue";
    context.lineWidth = 3;
    context.fillStyle = "blue";
    context.fillText("GAME OVER",650, 100)
  }
},1000)

  document.getElementById("remainnum").innerHTML = "남은수 : "+ deck.length;
  document.getElementById("failnum").innerHTML = "실패수 : "+ failnum;


}
function gamestop(){
  var audio = document.getElementById("bgm"); // 게임이 끝나면 노래 종료
  audio.pause();
  audio.currentTime = 0
  document.getElementById("remainnum").innerHTML = "";
  document.getElementById("failnum").innerHTML = "";
  document.getElementById("lefthour").innerHTML = "";
  document.getElementById("findanswer").innerHTML = "게임이 종료되었습니다.";
  clearTimeout(y);
  clearInterval(x);
  var canvas = document.getElementById("canvas");
  var context = canvas.getContext("2d");
  context.clearRect(0,0, canvas.width, canvas.height);
  context.font = "italic 100px forte";
  context.strokeStyle = "blue";
  context.lineWidth = 3;
  context.fillStyle = "blue";
  context.fillText("GAME STOPPED",650, 100)

}

//document.images[i].style.visibility - 12-1 // img 사라지게 만들

//settimeout - (11-2()) ex10-3 툴팁 메시지도 포//11-2 10-4 .ㅊㅐㅜ치ㅑ차  do rotate .onclick
// // hover : 알이 깜빡깜빢-(5-2) animation, transform - O
// // onlick :
// // flase 이면 부서진 알 true 이면 강아지
// //강아지가 들어있는 0~23번 의 태그에서 random으로 강아지 n갯수를 랜덤으로 지정후 랜덤으로 n개의 알을 뽑고 태그에 해당하는 알번호를 배열에 일치하는 지확인
// 그후에 알속의 강아지 출력
//  배열에서 알 제거 배열의 길이가 0이되면 success 출력 성공 말퀴 출
//  //(6-1 강)time을 사용해서 시간이 전부 사라지면 게임오버 출력 게임 정지 return 0으로 함수종ㄹ
//  //game의 시작은 gamestart() 함수를 출력할\
//
//
//
//  난이도 증가 메소드 시간을 짧게하고  fliping 보여주는 시간을 짧게 구현한다.


//프로도 집어넣기


 //이미지에 관하여 로딩완료  onload image 객체 new image(10-2)강의 myimg.src = "banana.png"

 //실습문제 3 - 10-2 확인할것
//점수 낼때 ex9-18 10-2 참고할거
//시간 얼마안남았다는 것을 빨간색 배경화면으로 표 7-2 date 객체를 활용(마지막 장)

// onclick 시에 카드이동 5-1주차 17번 으로 relative 구현할것


//firstletter 와 hover 이용해 4-1 34번 level 구현

//실패시 transition 구현
//제어기 만들기 ex13-2 -control(e) 에서 target.id해서 인덱슥값 가져오기 그후 innerHTMl 로 출력
//게임완료 시 배경 노란색 예지 13-4 or audio 반복 및 버튼음
