function sizeall(){
  window.resizeTo(200, 300);
}
